import time
import secrets

def submit_ticket(email, username, message):

    request_id = secrets.token_hex(8)

    return {
        "success": True,
        "message": f"Request queued successfully | ID: {request_id}",
        "email": email,
        "username": username,
        "timestamp": int(time.time())
    }
