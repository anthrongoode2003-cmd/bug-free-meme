from flask import Flask, render_template, request, jsonify
from services.support_api import submit_ticket

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/send", methods=["POST"])
def send():
    data = request.get_json()

    result = submit_ticket(
        email=data.get("email"),
        username=data.get("username"),
        message=data.get("message")
    )

    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
