async function sendData(){

const email = document.getElementById("email").value;
const username = document.getElementById("username").value;
const message = document.getElementById("message").value;

const result = document.getElementById("result");

result.innerHTML = "Processing...";

const response = await fetch("/api/send",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
email,
username,
message
})
});

const data = await response.json();

result.innerHTML = data.message;
}
